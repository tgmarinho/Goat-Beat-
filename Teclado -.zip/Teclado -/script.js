
window.addEventListener("keydown", function(evento) {
    
    const audio = document.querySelector(`audio[data-key="${evento.keyCode}"]`);
    if(!audio) return;
    audio.currentTime = 0;
    audio.play();
    
});
